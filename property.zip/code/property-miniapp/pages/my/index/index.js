const app = getApp()

Page({
  data: {
    list: [
      { "name": "我的信息", "url": "/pages/my/info/index" },
      { "name": "我的房屋", "url": "/pages/property/house/index" },
      { "name": "我的车辆", "url": "/pages/property/car/index" },
      { "name": "我的缴费", "url": "/pages/property/pay-list/index" },
      { "name": "我的报修", "url": "/pages/repair/publish-mine/index" }
    ]
  },

  onLoad() {

  },

  logout(){
    wx.removeStorage({
      key: 'token',
    })
    this.setData({
      member: null
    })
  },


  tabNav: function(e){
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: url,
    })
  },

  onShow() {
    if (!wx.getStorageSync('token')) {
      return;
    }

    this.getMember();
  },

  getMember: function () {
    var that = this;
    wx.request({
      url: app.globalData.domain + '/api/member/info',
      data: {
        token: wx.getStorageSync('token')
      },
      success: function (res) {
        if (res.data.code == 0) {
          that.setData({
            member: res.data.member
          })
        }
      }
    })
  },
  
  login: function(){
    wx.navigateTo({
      url: '/pages/login/index',
    })
  }

})