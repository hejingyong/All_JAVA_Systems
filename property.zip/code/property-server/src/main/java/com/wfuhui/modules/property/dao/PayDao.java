package com.wfuhui.modules.property.dao;

import com.wfuhui.modules.property.entity.PayEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 缴费
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface PayDao extends BaseDao<PayEntity> {

	List<Map<String, String>> queryPaySum();
	
}
