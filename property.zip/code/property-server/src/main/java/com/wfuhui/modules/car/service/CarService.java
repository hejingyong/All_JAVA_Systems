package com.wfuhui.modules.car.service;

import com.wfuhui.modules.car.entity.CarEntity;

import java.util.List;
import java.util.Map;

/**
 * 车俩
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
public interface CarService {
	
	CarEntity queryObject(Integer id);
	
	List<CarEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(CarEntity car);
	
	void update(CarEntity car);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
