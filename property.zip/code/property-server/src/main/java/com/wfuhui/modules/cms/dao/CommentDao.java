package com.wfuhui.modules.cms.dao;

import org.apache.ibatis.annotations.Mapper;

import com.wfuhui.modules.cms.entity.CommentEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

/**
 * 
 * @author lizhengle
 * @email 123456789@qq.com
 */
@Mapper
public interface CommentDao extends BaseDao<CommentEntity> {
	
}
