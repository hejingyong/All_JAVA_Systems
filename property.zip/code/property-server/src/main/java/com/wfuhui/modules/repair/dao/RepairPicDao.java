package com.wfuhui.modules.repair.dao;

import com.wfuhui.modules.repair.entity.RepairPicEntity;
import com.wfuhui.modules.sys.dao.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * 报修图片
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface RepairPicDao extends BaseDao<RepairPicEntity> {
	String[] queryByRepairId(Integer repairId);
}
