package com.wfuhui.modules.sys.dao;

import com.wfuhui.modules.sys.entity.MessageEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 消息
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 * @date 2020-09-24 11:15:42
 */
@Mapper
public interface MessageDao extends BaseDao<MessageEntity> {
	
}
