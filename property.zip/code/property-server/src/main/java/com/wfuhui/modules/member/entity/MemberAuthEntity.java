package com.wfuhui.modules.member.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 授权
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
public class MemberAuthEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//
	private Integer id;
	//用户ID
	private Long memberId;
	//openid
	private String openid;
	//授权类型
	private String authType;
	//创建时间
	private Date createTime;

	/**
	 * 设置：
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：用户ID
	 */
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}
	/**
	 * 获取：用户ID
	 */
	public Long getMemberId() {
		return memberId;
	}
	/**
	 * 设置：
	 */
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	/**
	 * 获取：
	 */
	public String getOpenid() {
		return openid;
	}
	/**
	 * 设置：授权类型
	 */
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	/**
	 * 获取：授权类型
	 */
	public String getAuthType() {
		return authType;
	}
	/**
	 * 设置：
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：
	 */
	public Date getCreateTime() {
		return createTime;
	}
}
