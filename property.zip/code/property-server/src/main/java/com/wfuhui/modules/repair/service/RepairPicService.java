package com.wfuhui.modules.repair.service;

import com.wfuhui.modules.repair.entity.RepairPicEntity;

import java.util.List;
import java.util.Map;

/**
 * 报修图片
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
public interface RepairPicService {
	
	RepairPicEntity queryObject(Integer id);
	
	List<RepairPicEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(RepairPicEntity repairPic);
	
	void update(RepairPicEntity repairPic);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
