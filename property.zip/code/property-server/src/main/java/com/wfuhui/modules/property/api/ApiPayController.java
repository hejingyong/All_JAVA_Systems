package com.wfuhui.modules.property.api;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wfuhui.common.utils.R;
import com.wfuhui.modules.property.entity.PayEntity;
import com.wfuhui.modules.property.service.PayService;

@RestController
@RequestMapping("/api/pay")
public class ApiPayController {
	
	@Autowired
	private PayService payService;

	@RequestMapping("/list")
	public R list(@RequestAttribute Long userId, @RequestParam Map<String, Object> params) {
		params.put("memberId", userId);
		List<PayEntity> payList = payService.queryList(params);
		return R.ok().put("payList", payList);
	}
	
	@RequestMapping("/detail")
	public R detail(Integer id) {
		PayEntity pay = payService.queryObject(id);
		return R.ok().put("pay", pay);
	}
	
	@RequestMapping("/pay")
	public R save(@RequestAttribute Long userId, Integer id){
		PayEntity pay = new PayEntity();
		pay.setId(id);
		pay.setStatus(2);
		pay.setPayTime(new Date());
		payService.update(pay);
		
		return R.ok();
	}
}
