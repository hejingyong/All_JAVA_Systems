package com.wfuhui.modules.house.dao;

import com.wfuhui.modules.house.entity.BuildingEntity;
import com.wfuhui.modules.sys.dao.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * 楼宇
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface BuildingDao extends BaseDao<BuildingEntity> {

}
