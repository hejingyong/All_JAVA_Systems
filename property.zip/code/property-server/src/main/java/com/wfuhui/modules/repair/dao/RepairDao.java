package com.wfuhui.modules.repair.dao;

import com.wfuhui.modules.repair.entity.RepairEntity;
import com.wfuhui.modules.sys.dao.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * 报修
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface RepairDao extends BaseDao<RepairEntity> {
	
}
