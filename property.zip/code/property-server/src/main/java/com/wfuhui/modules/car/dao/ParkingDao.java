package com.wfuhui.modules.car.dao;

import com.wfuhui.modules.car.entity.ParkingEntity;
import com.wfuhui.modules.sys.dao.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * 车位
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface ParkingDao extends BaseDao<ParkingEntity> {
	
}
