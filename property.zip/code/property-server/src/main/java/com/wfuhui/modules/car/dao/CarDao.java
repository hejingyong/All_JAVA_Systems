package com.wfuhui.modules.car.dao;

import com.wfuhui.modules.car.entity.CarEntity;
import com.wfuhui.modules.sys.dao.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * 车俩
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface CarDao extends BaseDao<CarEntity> {
	
}
