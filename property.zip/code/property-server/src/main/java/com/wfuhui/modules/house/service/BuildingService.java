package com.wfuhui.modules.house.service;

import com.wfuhui.modules.house.entity.BuildingEntity;

import java.util.List;
import java.util.Map;

/**
 * 楼宇
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
public interface BuildingService {

	BuildingEntity queryObject(Integer id);
	
	List<BuildingEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(BuildingEntity building);
	
	void update(BuildingEntity building);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
