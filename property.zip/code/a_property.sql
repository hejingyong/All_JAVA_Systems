/*
 Navicat MySQL Data Transfer

 Source Server         : taobishe
 Source Server Type    : MySQL
 Source Server Version : 50734
 Source Host           : 1.116.117.222:3306
 Source Schema         : a_property

 Target Server Type    : MySQL
 Target Server Version : 50734
 File Encoding         : 65001

 Date: 13/01/2023 16:12:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for base_member
-- ----------------------------
DROP TABLE IF EXISTS `base_member`;
CREATE TABLE `base_member`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `avatar_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `gender` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `real_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `mobile` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录账号',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 68 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of base_member
-- ----------------------------
INSERT INTO `base_member` VALUES (67, '清风', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTK3JVibuZg8wiaKG9ExyVJJT2R4s398eropw2qU7GhJEwgwNB8Y56GWh4dDHPSYTNcJXgmkvz4809SA/132', '1', '微服汇', '18112907714', 'test', '123456', '2021-03-09 23:50:00');

-- ----------------------------
-- Table structure for base_member_auth
-- ----------------------------
DROP TABLE IF EXISTS `base_member_auth`;
CREATE TABLE `base_member_auth`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '用户ID',
  `openid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT 'openid',
  `auth_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '授权类型',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `OPENID_UNIQUE`(`openid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '授权' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of base_member_auth
-- ----------------------------
INSERT INTO `base_member_auth` VALUES (1, 67, 'o1HEb0bbQgdd1aPNyr2ZXvutSU8U', 'wechat', '2022-05-04 17:10:30');

-- ----------------------------
-- Table structure for cms_article
-- ----------------------------
DROP TABLE IF EXISTS `cms_article`;
CREATE TABLE `cms_article`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '标题',
  `summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '摘要',
  `pic_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '图片地址',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL COMMENT '内容',
  `type` tinyint(2) NULL DEFAULT 1 COMMENT '文章类型：1文本图片，2视频',
  `video_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '视频地址',
  `vid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '腾讯视屏vid',
  `column_id` int(11) NULL DEFAULT NULL COMMENT '栏目id',
  `publish_date` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '文章' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cms_article
-- ----------------------------
INSERT INTO `cms_article` VALUES (104, '物业管理办法通知', '物业管理办法通知', 'http://localhost:8080/img/article-1.jpeg', '<p style=\"margin-top: 10px; margin-bottom: 20px; padding: 0px; list-style: none; line-height: 30px; word-break: break-all; color: rgb(25, 25, 25); font-family: &quot;PingFang SC&quot;, Helvetica, &quot;Microsoft YaHei&quot;, simsun, sans-serif; white-space: normal; background-color: rgb(249, 249, 249);\"><strong>央视网消息：</strong>面向贫困地区、服务贫困县的全国贫困地区农副产品网络销售平台——扶贫832平台上线一年来，交易额突破80亿元，累计带动百万农户，带贫作用明显。</p><p style=\"margin-top: 10px; margin-bottom: 20px; padding: 0px; list-style: none; line-height: 30px; word-break: break-all; color: rgb(25, 25, 25); font-family: &quot;PingFang SC&quot;, Helvetica, &quot;Microsoft YaHei&quot;, simsun, sans-serif; white-space: normal; background-color: rgb(249, 249, 249);\">开展消费扶贫，财政部、国务院扶贫办、中华全国供销合作总社共同发起组建扶贫832平台，运用政府采购政策，帮助贫困地区农副产品打开销路。2019年10月17日，贫困地区农副产品网络销售平台即扶贫832平台上线试运行，2020年1月起正式运营。</p><p style=\"margin-top: 10px; margin-bottom: 20px; padding: 0px; list-style: none; line-height: 30px; word-break: break-all; color: rgb(25, 25, 25); font-family: &quot;PingFang SC&quot;, Helvetica, &quot;Microsoft YaHei&quot;, simsun, sans-serif; white-space: normal; background-color: rgb(249, 249, 249);\"><strong>中国供销电子商务有限公司董事长 扶贫832平台负责人 丁好武：</strong></p><p style=\"margin-top: 10px; margin-bottom: 20px; padding: 0px; list-style: none; line-height: 30px; word-break: break-all; color: rgb(25, 25, 25); font-family: &quot;PingFang SC&quot;, Helvetica, &quot;Microsoft YaHei&quot;, simsun, sans-serif; white-space: normal; background-color: rgb(249, 249, 249);\">通过政府采购这一只手，运用市场化的机制来引导采购单位跟贫困地区有效对接，进一步加强脱贫地区农副产品货源的组织，为脱贫地区农副产品的销售创造一个稳定的渠道。</p><p><br/></p>', 1, NULL, NULL, NULL, '2021-01-25 21:44:10');
INSERT INTO `cms_article` VALUES (105, '疫情防控小区出入通知', '美国2020年航空客运量下降60.1% 创1984年以来最低纪录', 'http://localhost:8080/img/article-2.jpeg', '<p style=\"margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal; background-color: rgb(255, 255, 255);\"><span class=\"bjh-p\">据《国会山报》当地时间2月16日报道，受新冠疫情的影响，美国航空客运量在2020年下降了60.1%，创下自1984年以来的历史最低纪录。根据美国运输部的数据，2020年共有3.68亿名乘客乘坐飞机出行，而1984年的相关数据为3.516亿。</span></p><p style=\"margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal; background-color: rgb(255, 255, 255);\"><span class=\"bjh-p\">报道指出，由于国家之间的旅行限制，2020年的国际旅行需求较前1年下降70.4%，2020年全年，美国国内航空旅行总量减少58.7%，截至今年2月初，美国航空旅行需求下降60%。由于第二轮联邦薪资援助即将到期，加上航空业在疫情期间生意惨淡，美国航空公司和美国联合航空公司共同表示，届时将为27000名员工下达休假通知。行业贸易组织美国航空运输协会表示，美国最大的9家航空公司在2020年的税前亏损达460亿美元，旅客数量不太可能在2023年或2024年之前恢复到疫情前的水平。（央视记者 许弢）</span></p><p><br/></p>', 1, NULL, NULL, 67, '2021-01-25 21:44:00');
INSERT INTO `cms_article` VALUES (106, '物业费预缴通知', '美国2020年航空客运量下降60.1% 创1984年以来最低纪录', 'http://localhost:8080/img/article-2.jpeg', '<p style=\"margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal; background-color: rgb(255, 255, 255);\"><span class=\"bjh-p\">据《国会山报》当地时间2月16日报道，受新冠疫情的影响，美国航空客运量在2020年下降了60.1%，创下自1984年以来的历史最低纪录。根据美国运输部的数据，2020年共有3.68亿名乘客乘坐飞机出行，而1984年的相关数据为3.516亿。</span></p><p style=\"margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal; background-color: rgb(255, 255, 255);\"><span class=\"bjh-p\">报道指出，由于国家之间的旅行限制，2020年的国际旅行需求较前1年下降70.4%，2020年全年，美国国内航空旅行总量减少58.7%，截至今年2月初，美国航空旅行需求下降60%。由于第二轮联邦薪资援助即将到期，加上航空业在疫情期间生意惨淡，美国航空公司和美国联合航空公司共同表示，届时将为27000名员工下达休假通知。行业贸易组织美国航空运输协会表示，美国最大的9家航空公司在2020年的税前亏损达460亿美元，旅客数量不太可能在2023年或2024年之前恢复到疫情前的水平。（央视记者 许弢）</span></p><p><br/></p>', 1, NULL, NULL, 67, '2021-01-25 21:44:00');
INSERT INTO `cms_article` VALUES (111, '视频展示', '视频展示', 'http://localhost:8080/img/article-1.jpeg', '', 2, 'http://localhost:8080/img/video.mp4', NULL, 67, '2021-04-16 10:46:00');

-- ----------------------------
-- Table structure for cms_comment
-- ----------------------------
DROP TABLE IF EXISTS `cms_comment`;
CREATE TABLE `cms_comment`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `article_id` int(11) NULL DEFAULT NULL COMMENT '文章id',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '评论',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '评论' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cms_comment
-- ----------------------------
INSERT INTO `cms_comment` VALUES (22, 67, 105, '文章不错，值得学习', '2021-02-17 18:09:04');
INSERT INTO `cms_comment` VALUES (23, 67, 106, '文章很好', '2021-02-17 21:23:41');
INSERT INTO `cms_comment` VALUES (24, 67, 106, '你好你好', '2021-02-17 21:44:39');

-- ----------------------------
-- Table structure for cms_liked
-- ----------------------------
DROP TABLE IF EXISTS `cms_liked`;
CREATE TABLE `cms_liked`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `article_id` int(11) NULL DEFAULT NULL COMMENT '文章id',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '点赞' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cms_liked
-- ----------------------------
INSERT INTO `cms_liked` VALUES (111, 67, 106, '2021-08-06 22:06:18');

-- ----------------------------
-- Table structure for p_advert
-- ----------------------------
DROP TABLE IF EXISTS `p_advert`;
CREATE TABLE `p_advert`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片地址',
  `enable` tinyint(4) NULL DEFAULT NULL COMMENT '是否启用，0：禁用，1：启用',
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '链接',
  `sort` int(11) NULL DEFAULT NULL COMMENT '排序',
`remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '广告' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_advert
-- ----------------------------
INSERT INTO `p_advert` VALUES (2, 'http://localhost:8080/img/banner-2.jpg', 1, NULL, 2, NULL, '2020-10-31 13:45:13');
INSERT INTO `p_advert` VALUES (5, 'http://localhost:8080/img/banner-1.jpg', 1, NULL, 1, NULL, '2021-02-12 16:16:25');

-- ----------------------------
-- Table structure for p_building
-- ----------------------------
DROP TABLE IF EXISTS `p_building`;
CREATE TABLE `p_building`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '楼宇名称',
  `username` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '用户名称',
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '楼宇' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_building
-- ----------------------------
INSERT INTO `p_building` VALUES (3, '一栋', NULL,NULL, '2021-11-01 19:44:03');
INSERT INTO `p_building` VALUES (4, '二栋', NULL, NULL, '2021-11-01 19:44:15');
INSERT INTO `p_building` VALUES (5,'三栋', NULL, NULL, '2021-11-13 19:18:33');

-- ----------------------------
-- Table structure for p_car
-- ----------------------------
DROP TABLE IF EXISTS `p_car`;
CREATE TABLE `p_car`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `car_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '车牌号',
  `brand` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '汽车品牌',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '车俩' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_car
-- ----------------------------
INSERT INTO `p_car` VALUES (1, 67, '苏A12345', '奥迪', '2021-11-14 13:54:43');

-- ----------------------------
-- Table structure for p_house
-- ----------------------------
DROP TABLE IF EXISTS `p_house`;
CREATE TABLE `p_house`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building_id` int(11) NULL DEFAULT NULL COMMENT '楼宇id',
  `house_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '房屋编号',
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `house_type` tinyint(2) NULL DEFAULT NULL COMMENT '户型',
  `area` float(10, 2) NULL DEFAULT NULL COMMENT '面积',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '房屋' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_house
-- ----------------------------
INSERT INTO `p_house` VALUES (4, 3, 'A101', 67, 4, 150.00, NULL, '2021-11-13 21:51:29');
INSERT INTO `p_house` VALUES (5, 4, 'B001', 67, 3, 200.00, NULL, '2022-09-05 08:02:24');

-- ----------------------------
-- Table structure for p_parking
-- ----------------------------
DROP TABLE IF EXISTS `p_parking`;
CREATE TABLE `p_parking`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parking_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '车位编号',
  `car_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '车牌号',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '车位' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_parking
-- ----------------------------
INSERT INTO `p_parking` VALUES (1, 'H000001', '苏A12345', '2021-11-13 20:28:06');
INSERT INTO `p_parking` VALUES (2, 'H000001', '苏A12345', '2021-11-13 20:27:55');
INSERT INTO `p_parking` VALUES (3, 'H000002', '苏A88888', '2021-11-13 20:38:53');

-- ----------------------------
-- Table structure for p_pay
-- ----------------------------
DROP TABLE IF EXISTS `p_pay`;
CREATE TABLE `p_pay`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '金额',
  `type` tinyint(2) NULL DEFAULT NULL COMMENT '类型',
  `status` tinyint(2) NULL DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '备注',
  `pay_time` datetime(0) NULL DEFAULT NULL COMMENT '缴费时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '缴费' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of p_pay
-- ----------------------------
INSERT INTO `p_pay` VALUES (1, 67, 100.00, 1, 1, '请及时缴费', '2023-01-01 17:11:38', '2021-11-14 13:56:11');
INSERT INTO `p_pay` VALUES (2, 67, 1000.00, 1, 2, NULL, '2023-01-01 17:13:01', '2022-01-15 23:35:50');
INSERT INTO `p_pay` VALUES (3, 67, 1000.00, 1, 2, NULL, '2023-01-01 11:13:38', '2021-11-15 09:08:14');

-- ----------------------------
-- Table structure for r_repair
-- ----------------------------
DROP TABLE IF EXISTS `r_repair`;
CREATE TABLE `r_repair`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `real_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '姓名',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '电话',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '地点',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '问题描述',
  `status` tinyint(2) NULL DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '报修' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of r_repair
-- ----------------------------
INSERT INTO `r_repair` VALUES (1, 67, '张山', '18112907714', '单元门', '电灯不亮了', 1, NULL, '2021-03-29 16:25:18');
INSERT INTO `r_repair` VALUES (2, 67, '李珍珍', '18112907714', '公共场地', '座子坏了', 2, NULL, '2021-03-29 17:47:41');

-- ----------------------------
-- Table structure for r_repair_pic
-- ----------------------------
DROP TABLE IF EXISTS `r_repair_pic`;
CREATE TABLE `r_repair_pic`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repair_id` int(11) NULL DEFAULT NULL,
  `pic_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '报修图片' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of r_repair_pic
-- ----------------------------
INSERT INTO `r_repair_pic` VALUES (1, 1, 'http://localhost:8080/img/goods-1.jpg');
INSERT INTO `r_repair_pic` VALUES (2, 2, 'http://localhost:8080/img/goods-2.jpg');

-- ----------------------------
-- Table structure for sys_message
-- ----------------------------
DROP TABLE IF EXISTS `sys_message`;
CREATE TABLE `sys_message`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL COMMENT '内容',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `status` int(2) NULL DEFAULT NULL COMMENT '状态',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '消息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_message
-- ----------------------------
INSERT INTO `sys_message` VALUES (28, '消息标题', '物业消息通知测试', 67, 1, '2021-11-15 09:06:30');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '管理员' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2803180149@qq.com', '18021418906', 1, '2021-08-09 11:11:11');

SET FOREIGN_KEY_CHECKS = 1;
